package com.example.hakaton;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HakatonApplication {

	public static void main(String[] args) {
		SpringApplication.run(HakatonApplication.class, args);
	}

}
